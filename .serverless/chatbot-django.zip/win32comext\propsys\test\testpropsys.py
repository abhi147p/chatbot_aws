from win32com.propsys import propsys, pscon  # nopycln: import

print("propsys was imported (sorry - that is the extent of the tests,")
print("but see the shell folder_view demo, which uses this module)")
# that's all folks!
